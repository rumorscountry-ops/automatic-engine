import { useState, useEffect } from 'react';
import PayPalButton from './components/PayPalButton';

export default function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart((prev) => {
      const existing = prev.find((p) => p.id === product.id);
      if (existing) return prev.map((p) => p.id === product.id ? { ...p, qty: p.qty + 1 } : p);
      return [...prev, { ...product, qty: 1 }];
    });
  };

  const removeFromCart = (id) => {
    setCart((prev) => prev.filter((p) => p.id !== id));
  };

  const total = cart.reduce((acc, item) => acc + item.price * item.qty, 0);

  const SAMPLE_PRODUCTS = [
    { id: 'p1', title: 'Premium Drill Set', price: 129.99, image: 'https://images.unsplash.com/photo-1581092334384-1e7b59fc78aa', description: 'High-powered electric drill set with multiple bits.' },
    { id: 'p2', title: 'All-in-One Repair Kit', price: 79.99, image: 'https://images.unsplash.com/photo-1581090700227-4c4c1e3c46a4', description: 'Complete set of tools for everyday home fixes.' },
    { id: 'p3', title: 'Smart Measuring Tape', price: 49.99, image: 'https://images.unsplash.com/photo-1508896694512-1f7e2d3d8f23', description: 'Digital measuring tape with precision laser guide.' },
  ];

  // Load PayPal SDK dynamically
  useEffect(() => {
    const script = document.createElement('script');
    script.src = `https://www.paypal.com/sdk/js?client-id=${process.env.REACT_APP_PAYPAL_CLIENT_ID}`;
    script.async = true;
    document.body.appendChild(script);
    return () => document.body.removeChild(script);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-900 text-white p-4 text-center text-2xl font-bold">McGerald’s Online Shop</header>
      <main className="p-6">
        <h2 className="text-xl font-semibold mb-4">Featured Home Improvement Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {SAMPLE_PRODUCTS.map((p) => (
            <div key={p.id} className="bg-white rounded-2xl shadow-md p-4">
              <img src={p.image} alt={p.title} className="rounded-lg w-full h-40 object-cover mb-2" />
              <h3 className="font-bold text-lg">{p.title}</h3>
              <p className="text-gray-600">{p.description}</p>
              <p className="text-blue-800 font-semibold mt-2">${p.price}</p>
              <button onClick={() => addToCart(p)} className="mt-2 px-3 py-1 bg-blue-700 text-white rounded-xl">Add to Cart</button>
            </div>
          ))}
        </div>

        <div className="mt-10 bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-xl font-bold mb-4">Your Cart</h2>
          {cart.length === 0 ? <p>No items in cart.</p> : (
            <>
              {cart.map((item) => (
                <div key={item.id} className="flex justify-between items-center mb-2">
                  <span>{item.title} (x{item.qty})</span>
                  <div>
                    ${(item.price * item.qty).toFixed(2)}
                    <button onClick={() => removeFromCart(item.id)} className="ml-3 text-red-600">Remove</button>
                  </div>
                </div>
              ))}
              <hr className="my-3" />
              <p className="font-bold text-lg">Total: ${total.toFixed(2)}</p>
              <div className="mt-4"><PayPalButton amount={total} /></div>
            </>
          )}
        </div>
      </main>
      <footer className="bg-gray-800 text-white p-4 text-center mt-10">© {new Date().getFullYear()} McGerald’s Online Shop. All rights reserved.</footer>
    </div>
  );
}
